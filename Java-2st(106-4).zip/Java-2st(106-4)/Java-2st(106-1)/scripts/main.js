var regularIcon = "fa-regular fa-star";
var solidIcon = "fa-solid fa-star";
var isImportant = false;




function toggleImportant(){
    console.log('Icon clicked');

    if (!isImportant){
                            // Change to important

        $('#iImportant').removeClass(regularIcon); //remove non- important icon classess
        $('#iImportant').addClass(solidIcon); //remove non- important icon classess
        isImportant = True;
    }

    else{
        //change to non important
        $('#iImportant').removeClass(solidIcon); //remove non- important icon classess
        $('#iImportant').Class(regularIcon); //remove non- important icon classess
        isImportant = False;

    }
}
function saveTask(){
    console.log("Saving task!");
}

function init() {
    console.log('Task Manager page!');

    $('#iImportant').click(toggleImportant);
    $("#btnSave").click(saveTask);

    //load initial data
}

window.onload = init;